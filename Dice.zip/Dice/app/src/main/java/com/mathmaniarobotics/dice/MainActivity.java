package com.mathmaniarobotics.dice;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int roll;
    int die1;
    int die2;
    int die3;
    int die4;
    int die5;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    /*
    This function simulates rolling two dice (one right now)
     */
    public int rollDice() {
        //assign roll to a random number 1-6
        Random random = new Random();
        // generate random number from 0 to 3

        roll = (random.nextInt(6)+1);
        return roll;
    }

    /**
     * Displays the roll of one die.
     */
    public void displayOneDie(View view) {
        rollDice();
        TextView diceView = (TextView) findViewById(R.id.main_textView);
        diceView.setText("This is the roll: " + roll);
    }

    /**
     * Displays the roll of the 5 dice.
     */
    public void displayFiveDice(View view) {
        keepRolling();
        TextView diceView = (TextView) findViewById(R.id.main_textView);
        diceView.setText("Die 1:   " + die1 + "\nDie 2:   " + die2 + "\nDie 3:   " + die3 + "\nDie 4:   " + die4 + "\nDie 5:   " + die5 + "\nWe rolled 5 dice " + count + " times before hitting a Yahtzee.");
    }

    /*
    This function checks to see if the dice are equal
     */
    public int keepRolling() {
        die1 = rollDice();
        die2 = rollDice();
        die3 = rollDice();
        die4 = rollDice();
        die5 = rollDice();
        count = 1;
        while(!(die1 == die2 && die2 == die3 && die3 == die4 && die5 == die1)) {
            die1 = rollDice();
            die2 = rollDice();
            die3 = rollDice();
            die4 = rollDice();
            die5 = rollDice();
            count++;
        }
        return count;
    }
}